﻿Imports System.IO

Public Class Form1
    Property id As Integer
    Public Property MyImage As Object

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadDatagrid()
        TextBox2.PasswordChar = "*"c ' Mask the password input
    End Sub

    Sub LoadDatagrid()
        Using db As New Model1
            Dim a = (From s In db.Users
                     Where s.Fullname.StartsWith(TextBox5.Text) Or s.Username.StartsWith(TextBox5.Text)
                     Select New With {
                         .id = s.Id,
                         .Username = s.Username,
                         .Password = s.Password,
                         .Fullname = s.Fullname,
                         .Address = s.Address,
                         .DateCreated = s.DateCreated}).ToList()

            With DataGridView1
                .DataSource = a
            End With
            DataGridView1.Columns.Item(0).Visible = False
        End Using
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged
        LoadDatagrid()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        With OpenFileDialog1
            .Filter = "JPEGs|*.jpg|PNGs|*.png|GIFs|*.gif|BITMAPS|*.bmp"
            .FilterIndex = 1
        End With
        Dim a As DialogResult = OpenFileDialog1.ShowDialog()
        If (a = DialogResult.OK) Then
            If (OpenFileDialog1.FileName.CompareTo("") <> 0) Then
                Dim ThisImage = Image.FromFile(OpenFileDialog1.FileName)
                PictureBox1.BackgroundImage = ThisImage
            End If
        End If
    End Sub

    Public Function ImgtoByte(MyImage As Image) As Byte()
        Using instream As New MemoryStream()
            MyImage.Save(instream, MyImage.RawFormat)
            Return instream.ToArray()
        End Using
    End Function

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Using db As New Model1
            If id <= 0 Then
                Dim a = New User
                With a
                    .UserImage = ImgtoByte(PictureBox1.BackgroundImage)
                    .Username = TextBox1.Text
                    .Password = TextBox2.Text
                    .Fullname = TextBox3.Text
                    .Address = TextBox4.Text
                    .DateCreated = Now.Date
                End With
                db.Users.Add(a)
                If db.SaveChanges() Then
                    MsgBox("Save!")
                    LoadDatagrid()
                Else
                    MsgBox("Error!")
                End If
            Else
                Dim b = (From s In db.Users Where s.Id = id).FirstOrDefault()
                If b IsNot Nothing Then
                    With b
                        .UserImage = ImgtoByte(PictureBox1.BackgroundImage)
                        .Username = TextBox1.Text
                        .Password = TextBox2.Text
                        .Fullname = TextBox3.Text
                        .Address = TextBox4.Text
                        .DateCreated = Now.Date
                    End With
                    db.Entry(b).State = Entity.EntityState.Modified
                    If db.SaveChanges() Then
                        MsgBox("Save!")
                        LoadDatagrid()
                        loadClear()
                        id = 0
                    Else
                        MsgBox("Error!")
                    End If
                End If
            End If
        End Using
    End Sub

    Private Sub loadClear()

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        If e.RowIndex >= 0 Then
            id = DataGridView1.Rows(e.RowIndex).Cells(0).Value
            Using db As New Model1
                Dim a = (From s In db.Users Where s.Id = id).FirstOrDefault()
                If a IsNot Nothing Then
                    With a
                        If (.UserImage IsNot Nothing) Then
                            Dim instream As New MemoryStream(.UserImage)
                            Dim thisImgloc = Image.FromStream(instream)
                            PictureBox1.BackgroundImage = thisImgloc
                        Else
                            PictureBox1.BackgroundImage = My.Resources.abcd
                        End If
                        TextBox1.Text = .Username
                        TextBox2.Text = .Password
                        TextBox3.Text = .Fullname
                        TextBox4.Text = .Address
                    End With
                End If
            End Using
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Using db As New Model1
            Dim a = (From s In db.Users Where s.Id = id).FirstOrDefault
            db.Users.Remove(a)
            If db.SaveChanges Then
                MsgBox("Removed!")
                loadClear()
                LoadDatagrid()
                id = 0
            Else
                MsgBox("Error!")
            End If
        End Using
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        TextBox5.Clear()
    End Sub
End Class
