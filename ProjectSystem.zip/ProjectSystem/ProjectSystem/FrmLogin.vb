﻿Public Class FrmLogin
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Clear()
        TextBox2.Clear()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Using db As New Model1
            Dim a = (From s In db.Users Where s.Username = TextBox1.Text And s.Password = TextBox2.Text).FirstOrDefault
            If a IsNot Nothing Then
                Form1.Show()
                Me.Hide()
            Else
                MsgBox("error!")
            End If
        End Using
    End Sub
End Class