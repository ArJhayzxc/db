﻿Friend Class Modell
End Class
